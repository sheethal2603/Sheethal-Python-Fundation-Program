class Gallery:
    def __init__(self, gallery_id=None, name="", description="", location="", curator=None, opening_hours=""):
        self.gallery_id = gallery_id
        self.name = name
        self.description = description
        self.location = location
        self.curator = curator  # artist_id
        self.opening_hours = opening_hours
