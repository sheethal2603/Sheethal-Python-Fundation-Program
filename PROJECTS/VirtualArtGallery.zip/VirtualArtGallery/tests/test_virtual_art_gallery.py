import unittest
from datetime import datetime
from entity.artwork import Artwork
from dao.virtual_art_gallery_impl import VirtualArtGalleryImpl

class TestVirtualArtGallery(unittest.TestCase):

    def setUp(self):
        self.gallery = VirtualArtGalleryImpl()

    def test_add_artwork(self):
        art = Artwork(
            artwork_id=None,
            title="Sunset",
            description="Sunset over the hills",
            creation_date=datetime(2020, 5, 17),
            medium="Oil Painting",
            image_url="http://example.com/sunset.jpg",
            artist_id=1
        )
        result = self.gallery.add_artwork(art)
        self.assertTrue(result)


def test_update_artwork(self):
    # this will update an artwork with id 1 (should exist in your db)
    art = Artwork(
        artwork_id=1,
        title="Sunset Edited",
        description="Edited description",
        creation_date=datetime.date(2020, 5, 17),
        medium="Watercolor",
        image_url="http://example.com/sunset-new.jpg",
        artist_id=1
    )
    result = self.gallery.update_artwork(art)
    self.assertTrue(result)

def test_get_artwork_by_id(self):
    # fetch artwork with id 1
    art = self.gallery.get_artwork_by_id(1)
    # check that something is returned
    self.assertIsNotNone(art)

def test_search_artworks(self):
    # search for artworks with keyword 'Sunset'
    results = self.gallery.search_artworks("Sunset")
    self.assertIsInstance(results, list)

def test_remove_artwork(self):
    # try removing artwork with ID 1 (make sure it exists first)
    result = self.gallery.remove_artwork(1)
    self.assertTrue(result)

def test_add_artwork_to_favorite(self):
    # try adding artwork ID 2 to user ID 1's favorites
    result = self.gallery.add_artwork_to_favorite(user_id=1, artwork_id=2)
    self.assertTrue(result)

def test_remove_artwork_from_favorite(self):
    # try removing artwork ID 2 from user ID 1's favorites
    result = self.gallery.remove_artwork_from_favorite(user_id=1, artwork_id=2)
    self.assertTrue(result)

def test_get_user_favorite_artworks(self):
    # get favorites for user ID 1
    favorites = self.gallery.get_user_favorite_artworks(user_id=1)
    self.assertIsInstance(favorites, list)
